module.exports = {
	cookieSecret: "my_secret_abc_123"
};

