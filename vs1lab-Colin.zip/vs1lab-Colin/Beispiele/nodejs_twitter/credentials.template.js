module.exports = {
    cookieSecret: 'my_secret_abc_123',
    secret: 'my_secret_abc_123',
    cookie : {maxAge : 6000}, 
    twitter : {
    	consumerKey: "YOUR_KEY_HERE",
    	consumerSecret: "YOUR_SECRET_HERE",
    	callbackURL: "http://127.0.0.1:3005/test-login"
  	}
};

