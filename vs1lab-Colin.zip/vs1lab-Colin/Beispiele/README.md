# Code Beispiele zur Vorlesung

## Vorlesung node.js

- nodejs_networking (TCP Server)
- nodejs_webserver (Web Server ohne Express)
- nodejs_express (Einfache Express Web App)

## Vorlesung ajax & co

- nodejs_todo_app (Express Web App mit JSON und Ajax)
- nodejs_connect (Connect Middleware)
- nodejs_ejs (ejs Templates)

## Vorlesung p13n

- nodejs_cookies (Cookies im Server)
- browser_cookies (Cookies im Client)
- nodejs_session (Server Sesions in Express)
- nodejs_twitter (3'rd Party Authentifikation per Twitter)

## Vorlesung Sicherheit

- nodejs_inject (Inject Angriff)
