module.exports = {
    cookieSecret: 'my_secret'
};
